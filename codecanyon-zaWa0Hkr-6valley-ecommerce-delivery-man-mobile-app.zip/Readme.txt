If you need only the changed files for delivery man app in V4.5 check the files in changed files from V4.4 to V4.5 folder otherwise please use delivery man app folder.

Documentation - https://6valley.app/documentation/